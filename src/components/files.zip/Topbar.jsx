// components/host/Topbar.jsx

const PAGE_TITLES = {
  dashboard:    "Dashboard Overview",
  bookings:     "Bookings",
  availability: "Availability Calendar",
  rates:        "Rates & Pricing",
  rooms:        "Room Types",
  listing:      "Listing Details",
  photos:       "Photos & Media",
  channel:      "Channel Manager",
  analytics:    "Analytics",
  settings:     "Settings",
};

export default function Topbar({ activePage, onOpenModal }) {
  return (
    <div className="hd-topbar">
      <div className="hd-topbar-title">{PAGE_TITLES[activePage] || activePage}</div>
      <div className="hd-topbar-actions">
        <div className="hd-sync-pulse">
          <div className="hd-sync-dot" />
          Live sync active
        </div>
        <button className="hd-btn hd-btn-outline hd-btn-sm" onClick={onOpenModal}>
          + Update Rates
        </button>
        <button className="hd-btn hd-btn-primary hd-btn-sm">
          New Booking Block
        </button>
        <div className="hd-avatar">EK</div>
      </div>
    </div>
  );
}
